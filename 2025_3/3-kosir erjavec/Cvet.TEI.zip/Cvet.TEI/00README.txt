      Corpus of texts by Hijacint Repič in "Cvetje z vertov sv. Frančiška" 
                              CVET 1.0

    Citation, documentation, download, and licence available from
                   http://hdl.handle.net/11356/1226

This directory contains the TEI encoded corpus without linguistic
annotations.
